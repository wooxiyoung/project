package com.peisia.c.site.display;

import com.peisia.c.util.Cw;

public class DispSite {
	static private String SITE_NAME = "NEVER";
	static private String VERSION = " ver.0.0";
	static public void entranceTitle() {
		Cw.w("==========================================");
		Cw.w(SITE_NAME);
		Cw.w(VERSION);
		Cw.wn("==========================================");
	}	
}
