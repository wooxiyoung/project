package com.peisia.c.member;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class ProcMemberLogin {
	public static String id="";
	public static String pw="";
	static public String run() {	/* 로그인 처리 */

		//id,pw 를 디비에 저장. ex. insert into member values('nyang','1234');
		if(Db.isProcLogin(id,pw)==1) {	//로그인 처리
			return id;
			
		}else {	//로그인 실패 처리
			Cw.wn("로그인 실패");
			return null;
		}
	}
}