package com.peisia.c.mysqlboard;

import com.peisia.c.site.SiteMain;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class ProcDel {
	static public void run() {
		String delNo = Ci.r("삭제할 글번호를 입력해주세요:");
		b: while (true) {
			try {
				Db.result = Db.st.executeQuery("select * from board where b_no =" + delNo);
				Db.result.next();
				String title = Db.result.getString("b_title"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String content = Db.result.getString("b_text"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)\
				
				//정보값이 존재하지 않으면 이전 메뉴로 이동
				if (title == null) {
					Cw.wn("정보가 존재하지 않아 이전 메뉴로 이동합니다");
					break b;
				}
				
				//정보값이 있는 경우 글제목,내용 출력하기
				else {
				Cw.line();
				Cw.wn("글제목: " + title);
				Cw.wn("글내용: " + content);
				Cw.line();

				String cmd = Ci.r("정말 삭제하시겠습니까? [1]YES [2]NO");
				switch (cmd) {
				case "1":

					String id = Db.result.getString("b_id");
					if (SiteMain.loginedId.equals(id)) {
						Db.dbExecuteUpdate("delete from board where b_no=" + delNo);
						Cw.wn("삭제되었습니다");
						Cw.wn("이전 메뉴로 이동합니다");
					} else {
						Cw.wrong();
					}
					break b;
				case "2":
					Cw.wn("이전 메뉴로 이동합니다");
					break b;
				}
				}
			} 
			catch (Exception e) {
			}
		}
		}
	}
