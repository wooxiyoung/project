package com.peisia.c.mysqlboard;



import com.peisia.c.mysqlboard.display.DispBoard;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class ProcList {
	static public final int PER_PAGE = 3;
	static int startIndex = 0;		// 현재 페이지의 첫 글 인덱스
	static int currentPage = 1;		// 현재 페이지
	static int searchCurrentPage = 1; //검색화면 현재 페이지
	static boolean isSearchMode = false;	// 현재 리스트가 검색 모드인지 구분하는 값
	static int totalPage = 0;
	static int count = 0;
	
	static int clickcount = 1;
	static public void run() {
		String cmd = "";
		////	전체 페이지 수를 구하기	////
		count = Db.getPostCount(); 
		if(count % PER_PAGE > 0) {
			totalPage = count / PER_PAGE + 1;
		}else {
			totalPage = count / PER_PAGE;
		}
		Cw.wn("전체 글수:" + Db.getPostCount());
		while(true) {
			//글리스트를 처음 진입할 때 맨 첫번째 페이지가 보일 수 있게 구동,페이지번호를 입력하면 사라짐
			while(cmd.equals("")) {
			String firstpage= "select * from board where b_reply_ori is null order by b_no desc limit "+0+","+PER_PAGE;
			DispBoard.titleList();
			DispBoard.bar();
			try {
				Db.result = Db.st.executeQuery(firstpage);
				while(Db.result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
					String no = Db.result.getString("b_no");
					String title = Db.result.getString("b_title");
					String id = Db.result.getString("b_id");
					String datetime = Db.result.getString("b_datetime");
					Cw.wn(String.format("%6.6s", no)+"|"+String.format("%-15.12s", title)+"|"+String.format("%15.12s", id)+"|"+String.format("%-15.24s", datetime));
				}
			} catch (Exception e) {
			}
			break;
			}
			Cw.wn("현재 페이지/총 페이지 수:"+currentPage+"/"+totalPage);
			cmd = Ci.r("페이지번호입력[이전 메뉴로:x]");
			if(cmd.equals("x")) {
				currentPage = 1;
				searchCurrentPage = 1;
				cmd = "";
				break;
			}
		
			currentPage = Integer.parseInt(cmd);
			if(currentPage > totalPage || currentPage < 1) {
				Cw.wn("페이지 범위에 맞는 값을 넣어주세요");
				continue;
			}
			startIndex = (currentPage - 1) * PER_PAGE;	// 페이지의 첫 인덱스를 계산해서 저장하기
			DispBoard.titleList();
			DispBoard.bar();
			String sql = "select * from board where b_reply_ori is null order by b_no desc limit "+startIndex+","+PER_PAGE;
			
			try {
				Db.result = Db.st.executeQuery(sql);
				while(Db.result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
					String no = Db.result.getString("b_no");
					String title = Db.result.getString("b_title");
					String id = Db.result.getString("b_id");
					String datetime = Db.result.getString("b_datetime");
					Cw.wn(String.format("%6.6s", no)+"|"+String.format("%-15.12s", title)+"|"+String.format("%15.12s", id)+"|"+String.format("%-15.24s", datetime));
				}
			} catch (Exception e) {
			}			
		}
	}
	/* 검색어를 입력받아 리스트-검색 처리 */
	static public void search() {
		String cmd = "";
		cmd=Ci.rl("검색어[x:나가기]");
		if(cmd.equals("x")) {
			currentPage = 1;
			searchCurrentPage = 1;
			clickcount =1;
			cmd = "";
			return;
		}else {
			searchList(cmd);
		}
	}
	/* 리스트-검색 처리 */
	static public void searchList(String searchWord) {
		////	전체 페이지 수를 구하기	////
		count = Db.getPostCountSearch(searchWord); 
		if(count % PER_PAGE > 0) {
			totalPage = count / PER_PAGE + 1;
		}else {
			totalPage = count / PER_PAGE;
		}
		
		
		if(clickcount == 1) {//검색하면 첫번째 페이지가 무조건 나오게
			
			String firstpage = "select * from board where b_reply_ori is null"
					+ " and b_title like '%" + searchWord + "%'"
					+ "order by b_no desc limit "+0+","+PER_PAGE;
			DispBoard.titleList();
			DispBoard.bar();
			try {
				Db.result = Db.st.executeQuery(firstpage);
				while(Db.result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
					String no = Db.result.getString("b_no");
					String title = Db.result.getString("b_title");
					String id = Db.result.getString("b_id");
					String datetime = Db.result.getString("b_datetime");
					Cw.wn(String.format("%6.6s", no)+"|"+String.format("%-15.12s", title)+"|"+String.format("%15.12s", id)+"|"+String.format("%-15.24s", datetime));
					clickcount =2;
				}
			} catch (Exception e) {
			}
			}
		
		
		while(true) {
			String cmd = "";
			Cw.wn("현재 페이지/총 페이지 수:"+searchCurrentPage+"/"+totalPage);
			cmd = Ci.r("페이지번호입력<검색모드>[이전 메뉴로:x]:");
			if(cmd.equals("x")) {
				currentPage = 1;
				searchCurrentPage = 1;
				break;
			}
			searchCurrentPage = Integer.parseInt(cmd);
			if(searchCurrentPage > totalPage || currentPage < 1) {
				Cw.wn("페이지 범위에 맞는 값을 넣어주세요");
				continue;
			}
			startIndex = (searchCurrentPage - 1) * PER_PAGE;	// 페이지의 첫 인덱스를 계산해서 저장하기
			DispBoard.titleList();
			DispBoard.bar();
			String sql = "select * from board where b_reply_ori is null"
					+ " and b_title like '%" + searchWord + "%'"
					+ "order by b_no desc limit "+startIndex+","+PER_PAGE;
			try {
				Db.result = Db.st.executeQuery(sql);
				while(Db.result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
					String no = Db.result.getString("b_no");
					String title = Db.result.getString("b_title");
					String id = Db.result.getString("b_id");
					String datetime = Db.result.getString("b_datetime");
					Cw.wn(String.format("%6.6s", no)+"|"+String.format("%-15.12s", title)+"|"+String.format("%15.12s", id)+"|"+String.format("%-15.24s", datetime));
				}
			} catch (Exception e) {
			}			
		}		
	}
}