package com.peisia.c.mysqlboard;

import com.peisia.c.mysqlboard.display.DispBoard;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;

public class ProcVisiter {
	public static void run() {
		loop: while (true) {
			DispBoard.bar();
			Cw.wn("방문자모드입니다");
			String cmd = Ci.r("[1]글리스트 [2]글읽기 [3]검색 [x]이전 메뉴로 이동");
			switch (cmd) {

			case "1":
				ProcList.run();

				break;

			case "2":
				ProcRead.run();

				break;

			case "3":
				ProcList.search();

				break;

			case "x":
				break loop;
			}
		}
		
		
		
	}
}
