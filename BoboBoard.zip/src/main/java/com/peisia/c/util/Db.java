package com.peisia.c.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Db {
	static private String DB_NAME = "my_cat";
	static private String DB_ID = "root";
	static private String DB_PW = "root";
	static public Connection con = null;
	static public Statement st = null;
	static public ResultSet result = null;
	static public void dbInit() {
		try {
			Db.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DB_NAME, DB_ID, DB_PW);
			Db.st = Db.con.createStatement();
		} catch (Exception e) { e.printStackTrace();
		}
	}	
	static public int dbMemberUpdate(String id, String pw,  String nickname,String gender, String phone, String birth_date) {
		int resultCount=0;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
			String sql = "insert into bobomember(id,pw,nickname,gender,phone,birth_date) values('"+id+"','"+pw+"','"+nickname+"','"+gender+"','"+phone+"','"+birth_date+"')";
			Cw.wn(sql);
			resultCount = st.executeUpdate(sql);
		} catch (Exception e) { e.printStackTrace();
		}
		return resultCount;
	}
	
	static public void dbBoardUpdate(String query) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
			int resultCount = st.executeUpdate(query);
		} catch (Exception e) { e.printStackTrace();
		}
	}

	
	static public void dbPostCount() {	
		try {
			Db.result = Db.st.executeQuery("select count(*) from board where b_reply_ori is null");
			Db.result.next();
			String count = Db.result.getString("count(*)");
			Cw.wn("글 수:"+count);
		} catch (Exception e) {
		}
	}
	static public int getPostCount() {
		String count = "";
		try {
			result = Db.st.executeQuery("select count(*) from Boboboard where reply_num is null");
			result.next();
			count = result.getString("count(*)");
		} catch (Exception e) { e.printStackTrace();
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}
	static public int getPostCountSearch(String searchWord) {
		String count = "";
		try {
			Db.result = Db.st.executeQuery(
					"select count(*) from board where b_reply_ori is null"
					+
					" and b_title like '%"+searchWord+"%'"
			);
			Db.result.next();
			count = Db.result.getString("count(*)");
			Cw.wn("글 수:"+count);
		} catch (Exception e) { e.printStackTrace();
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}
	/* 로그인 처리 */
	static public int isProcLogin(String id, String pw) {
		String count = "";
		int y=0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
			String sql = "select count(*) from bobomember where id='"+id+"' and pw='"+pw+"'";
			result = st.executeQuery(sql);
			result.next();
			count = result.getString("count(*)");
			y = Integer.parseInt(count);
		} catch (Exception e) { e.printStackTrace();
		}
		if(y==1) {
		}else {
		}
		return y;
	}
	static public int getReplyCount() {
		String count = "";
		try {
			Db.result = Db.st.executeQuery("select count(*) from board where reply_num is null");
			Db.result.next();
			count = Db.result.getString("count(*)");
		} catch (Exception e) { e.printStackTrace();
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}
	static public String search_nickname(String id) {
		String nickname="";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
			String sql = "select * from bobomember where id='"+id+"'";
			Cw.wn(sql);
			result = st.executeQuery(sql);
			result.next();
			nickname = result.getString("nickname");
			
		} catch (Exception e) { e.printStackTrace();
		}
		return nickname;
	}
	
}